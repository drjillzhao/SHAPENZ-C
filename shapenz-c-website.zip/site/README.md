# SHAPEing Net Zero Collective — website

A rebuild of the Wix site (`drjillzhao.wixsite.com/shapenz-c`) as a plain, fast,
static site with **no hosting fees** and **multiple editors**.

- **Pages:** Home, Members, Events, Publications
- **Content:** lives in `/content/*.json`, kept separate from layout/design
- **Editing:** either (a) a visual dashboard at `/admin`, or (b) editing the
  JSON files directly on GitHub — both are just commits to this repo, so
  every change is versioned and any editor can be added as a collaborator
- **Hosting:** GitHub Pages (free, no server to maintain)

---

## 1. Put this on GitHub

1. Create a new **public** repo on GitHub, e.g. `shapenz-c`.
2. Upload everything in this folder to the repo (drag-and-drop on
   github.com works, or `git init && git add . && git commit -m "site" && git push`).
3. Go to **Settings → Pages** in the repo, set **Source: Deploy from a
   branch**, branch `main`, folder `/ (root)`. Save.
4. After a minute your site is live at
   `https://YOUR-USERNAME.github.io/shapenz-c/`.

## 2. Add your editors (this is what makes it multi-editor)

Go to **Settings → Collaborators → Add people** and invite everyone who
should be able to edit content. Every collaborator can then:

- edit the JSON files straight on github.com (click a file → pencil icon →
  edit → "Commit changes"), **or**
- use the `/admin` dashboard once you finish the one-time setup below —
  no git knowledge required, it's just a form.

There's no seat limit and no cost either way.

## 3. One-time setup for the `/admin` dashboard (optional but recommended)

The dashboard is [Decap CMS](https://decapcms.org) — free, open-source, and
it saves every edit as a GitHub commit. Because the site is on GitHub Pages
(not Netlify), GitHub requires a small "OAuth proxy" to handle logins. This
is a **free** Cloudflare Worker that takes 5 minutes to deploy once:

1. **Create a GitHub OAuth App:** GitHub → Settings → Developer settings →
   OAuth Apps → New OAuth App.
   - Homepage URL: `https://YOUR-USERNAME.github.io/shapenz-c/`
   - Authorization callback URL: `https://decap-proxy.YOUR-SUBDOMAIN.workers.dev/callback`
     (you'll get this exact URL in step 2 — come back and fill it in)
   - Save the **Client ID** and **Client Secret**.

2. **Deploy the OAuth proxy on Cloudflare (free tier):**
   - Sign up at [cloudflare.com](https://cloudflare.com) (no credit card
     needed for Workers' free tier).
   - Use the template at
     [github.com/sterlingwes/decap-proxy](https://github.com/sterlingwes/decap-proxy)
     — follow its README to deploy with `wrangler`, then add your GitHub
     Client ID/Secret as Worker secrets (`GITHUB_OAUTH_ID`,
     `GITHUB_OAUTH_SECRET`).
   - Note the Worker's URL, e.g. `https://decap-proxy.yourname.workers.dev`.

3. **Point the dashboard at your repo and proxy:** edit `admin/config.yml`
   in this repo and replace the three placeholders:
   - `repo:` → `YOUR-USERNAME/shapenz-c`
   - `base_url:` → your Worker URL from step 2
   - `site_url:` / `display_url:` → your GitHub Pages URL

4. Commit that change, then visit
   `https://YOUR-USERNAME.github.io/shapenz-c/admin/` and click **Login
   with GitHub**. Any collaborator you added in step 2 can log in the same
   way — GitHub's own permissions decide who can edit, so there's nothing
   extra to manage.

If you'd rather skip this setup, editors can always just edit the JSON
files directly on github.com — fully functional, just less polished.

## 4. Editing content

| To change...        | Edit this file            |
|----------------------|----------------------------|
| Org name, tagline, intro, story, contact info | `content/site.json` |
| Homepage news posts  | `content/news.json`        |
| Events (past/upcoming SMMs) | `content/events.json` |
| Member profiles      | `content/members.json`     |
| Publications list    | `content/publications.json`|

Each of these is a small, readable JSON file. Through `/admin` they're
presented as forms instead. Images uploaded via `/admin` are saved to
`/images`.

## 5. Contact form

The form on the homepage is currently a placeholder (it shows a message on
submit but doesn't send anywhere, since GitHub Pages can't run server code).
To make it work for free, connect it to a form service like
[Formspree](https://formspree.io) (free tier) or
[EmailJS](https://www.emailjs.com/) — both just need the `<form>` tag's
`action`/`onsubmit` updated in `index.html`, no backend required.

## 6. Preview locally

Any static file server works, e.g. from this folder:

```
python3 -m http.server 8000
```

then open `http://localhost:8000`.

## Notes on this rebuild

- Text and event history were pulled from the current Wix site. Member and
  publication entries are placeholders — replace them via `/admin` or by
  editing `content/members.json` / `content/publications.json`.
- Images are simple placeholder graphics (`/images/*.svg`) since the
  original photos live on Wix's private media host. Swap them for real
  photos any time — via `/admin` (uploads to `/images`) or by replacing the
  files directly and updating the matching `image` field in the JSON.
